if (!window.webshop) window.webshop = {}
if (!frappe.boot) frappe.boot = {}
